package org.redbus.tests;

import java.util.concurrent.TimeUnit;

import org.CommonConfig.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.redbus.pages.RBloginPage;
import org.redbus.pages.RBlogoutPage;
import org.testng.annotations.Test;

@Test (priority =3, description = "TC_9 : Logout from redbus ")
public class redbusLogoutTest extends TestBase {
 
	  

	  public void logout() throws InterruptedException {
		  
 				    
				    //Create object of Page class
				    RBlogoutPage logoutPageObj = new RBlogoutPage(driver);
				    
				    //Refer action methods of page class
				    driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				    
				    logoutPageObj.profileicon();
				    
				    logoutPageObj.signoutlink();
				    
				    
}
}