package org.redbus.tests;

import java.util.concurrent.TimeUnit;

import org.CommonConfig.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.redbus.pages.RBsearchPage;
import org.testng.annotations.Test;

import jdk.nashorn.internal.runtime.regexp.joni.SearchAlgorithm;

@Test (priority =0, description = "TC_1_2_3_4 : Search Buses using FromDest, toDest, onward_date ")
public class redbusSearchTest extends TestBase {
  
	
	public static void searchbuses() throws InterruptedException
	{
	
		
		    //Create object of Page class
		    RBsearchPage searchPageObj = new RBsearchPage(driver);
   
		    
		    //Refer action methods from page class
		    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		    
		    searchPageObj.setTextInSource(); //TC1
		    
		    searchPageObj.setTextInTo(); //TC2
		    
		    searchPageObj.setOnwardDate(); //TC3
	   
		    searchPageObj.searchBuses(); //TC4
		    
		    
		    
	}
	
}
