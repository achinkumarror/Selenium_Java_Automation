package org.redbus.tests;

import java.util.concurrent.TimeUnit;

import org.CommonConfig.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.redbus.pages.RBresultgridpage;
import org.redbus.pages.RBsearchPage;
import org.testng.annotations.Test;

@Test (priority =1, description = "TC_5_6_7 : Filter result Buses on DepartureTime, BusTypes, ArrivalTime")
public class redbusResultGridTest extends TestBase{
 
	

	public static void filterbusresult() throws InterruptedException
	{
 
		    
		    //Create object of Page class
		    RBresultgridpage FilterPageObj = new RBresultgridpage(driver);
		    
		    //Refer action methods from page class
		    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		    
		    FilterPageObj.filterByDepartureTime(); //TC5
		    
		    FilterPageObj.filterByBusType(); //TC6
		    
		    FilterPageObj.filterByArrivalTime(); //TC7
		    Thread.sleep(3000);
		    
		    
}
}
