package org.redbus.tests;

import java.util.concurrent.TimeUnit;

import org.CommonConfig.TestBase;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.redbus.pages.RBloginPage;
import org.redbus.pages.RBsearchPage;
import org.testng.annotations.Test;

@Test (priority =2, description = "TC_8 : Login to RedBus via Google")
public class redbusLoginTest extends TestBase {
	

  public void redbudlogin() throws InterruptedException {
	  		    
			    
			    //Create object of Page class
			    RBloginPage loginPageObj = new RBloginPage(driver);
			    
			    
			    //Refer action methods of page class
			    driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			    loginPageObj.profileicon();
			    
			    loginPageObj.signinlink();
			    
			    loginPageObj.switchframe();
			    
			    loginPageObj.googlebutton();
			    
			    loginPageObj.switchwindow();
			    	    
			    Thread.sleep(4000);

	}
}
