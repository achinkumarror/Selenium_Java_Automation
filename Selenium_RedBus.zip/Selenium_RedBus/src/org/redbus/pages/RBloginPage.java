package org.redbus.pages;

import java.util.Set;

import org.CommonConfig.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;


//TC2  - Login to RedBus webapp
public class RBloginPage extends TestBase {
	
	
	//Object Locator
	By profileicon = By.xpath("//i[@id='i-icon-profile']");
	By signinlink = By.xpath("//li[@id='signInLink']");
	By frame1 = By.xpath("//iframe[@class='modalIframe']");
	By Googlebutton = By.xpath("//div[@id='customBtn']");
	By goog_userName = By.xpath("//input[@id='identifierId']");
	By nxt_btn = By.id("identifierNext");
	By goog_password = By.xpath("//input[@name='password']");
	By nxt_pass_btn = By.id("passwordNext");
	
	By frame_close_btn = By.xpath("//div[@class='modalFrame']");
	By frame_close_btn_mobilenbr = By.xpath("//input[@id='mobileNo']");
	By close_btn = By.xpath("//i[@class='icon-close']");
	
	
	//Constructor
	public RBloginPage(WebDriver driver)
	{
		this.driver =driver;
	}
	
	
	//Action Methods

	public void profileicon()
	{
		driver.findElement(profileicon).click();
		
	}
	
	public void signinlink() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(signinlink).click();
		
	}
	
	public void switchframe() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.switchTo().frame(2); //
	}
	
	public void googlebutton() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(Googlebutton).click();
	}
	
	
	public void switchwindow() throws InterruptedException
	{
		Thread.sleep(2000);
		String ph = driver.getWindowHandle();  
		Set<String> allh = driver.getWindowHandles(); 

		for (String i: allh)
				  {
					  System.out.println(i);
					  if(!i.equals(ph))  //if not equal to parent window
					  {
						  driver.switchTo().window(i);
		                          }
		                  }
		
		Thread.sleep(2000);
		driver.findElement(goog_userName).sendKeys("achinkumarror@gmail.com");
		driver.findElement(nxt_btn).click();
		Thread.sleep(2000);
		driver.findElement(goog_password).sendKeys("Hind@2017");
		Thread.sleep(2000);
		driver.findElement(nxt_pass_btn).click();
		//switch_back_to_default_content(); 
		
		Thread.sleep(10000);
        driver.switchTo().window(ph);
        driver.findElement(By.xpath("//i[@class='icon-close']")).click();
        Thread.sleep(2000);
	}
}
	
	