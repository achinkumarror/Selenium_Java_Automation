package org.redbus.pages;

import org.CommonConfig.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;



public class RBsearchPage extends TestBase{
  

	
	//Object Locator
	By textBoxSource = By.xpath("//input[@id='src']");
	By sourcedropdown = By.xpath("//li[@class='selected'][contains(text(),'New Delhi')]");
	By textBoxTo = By.xpath("//input[@id='dest']");
	By todropdown = By.xpath("//li[@class='selected'][contains(text(),'Chandigarh')]");
	By textBoxOnwardCal = By.xpath("//input[@id='onward_cal']");
	By OnwardDate = By.xpath("//div[@id='rb-calendar_onward_cal']//td[@class='wd day'][contains(text(),'20')] ");
	By textBoxReturnDate = By.xpath("//input[@id='return_cal']");
	By buttonSearchBuses = By.xpath("//button[@id='search_btn']");
	
	//Constructor
	public RBsearchPage(WebDriver driver)
	{
		this.driver =driver;
	}
	
	//Action Methods
	public void setTextInSource() throws InterruptedException
	{
		driver.findElement(textBoxSource).sendKeys("New Delhi");
		Thread.sleep(2000);
		driver.findElement(sourcedropdown).click();
		driver.findElement(textBoxSource).sendKeys(Keys.TAB);
	}
	
	public void setTextInTo() throws InterruptedException
	{
		driver.findElement(textBoxTo).sendKeys("Chandigarh");
		Thread.sleep(2000);
		driver.findElement(todropdown).click();
		driver.findElement(textBoxSource).sendKeys(Keys.TAB);
	}
	


	public void setOnwardDate() throws InterruptedException
	{
		driver.findElement(textBoxOnwardCal).sendKeys(Keys.ENTER);
		//driver.findElement(textBoxOnwardCal).click();
		Thread.sleep(1000);
		driver.findElement(OnwardDate).click();
	}
	
	public void searchBuses() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(buttonSearchBuses).click();
		Thread.sleep(1000);
		driver.findElement(buttonSearchBuses).sendKeys(Keys.ENTER);
	}
	
}
