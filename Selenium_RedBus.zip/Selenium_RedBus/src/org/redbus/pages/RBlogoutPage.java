package org.redbus.pages;

import org.CommonConfig.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class RBlogoutPage extends TestBase{

	
	//Object Locator
	By profileicon = By.xpath("//i[@id='i-icon-profile']");
	By signoutlink = By.xpath("//li[@id='signOutLink']");
	

	//Constructor
	public RBlogoutPage(WebDriver driver)
	{
		this.driver =driver;
	}
	
//Action Methods
	public void profileicon()
	{
		driver.findElement(profileicon).click();
		
	}
	
	public void signoutlink()
	{
		driver.findElement(signoutlink).click();
		
	}
}
