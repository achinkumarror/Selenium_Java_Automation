package org.redbus.pages;

import org.CommonConfig.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class RBresultgridpage extends TestBase{
  
	
	//Object Locator
	By DepartureTimechkbox = By.xpath("//ul[@class='dept-time dt-time-filter']//li[1]//label[2]");
	By  BusType = By.xpath("//ul[@class='list-chkbox']//li[2]//label[2]");
	By ArrivalTime = By.xpath("//ul[@class='dept-time at-time-filter']//li[1]//label[2]");
	
	//Constructor
	public RBresultgridpage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	//Action methods
	public void filterByDepartureTime() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(DepartureTimechkbox).click();
		
	}
	
	public void filterByBusType() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(BusType).click();
		
	}
	
	public void filterByArrivalTime() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(ArrivalTime).click();
		
	}
}
