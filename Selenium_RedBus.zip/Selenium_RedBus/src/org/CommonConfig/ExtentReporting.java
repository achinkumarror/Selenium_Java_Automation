package org.CommonConfig;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReporting
{
	public ExtentHtmlReporter htmlreport;
	public ExtentReports extent;
	public ExtentTest exttest;
	
  @BeforeTest
  public void SetExtent() {
	  htmlreport = new ExtentHtmlReporter (System.getProperty("user.dir")+"/test-output/redbusreport.html"); //location of html report
	  htmlreport.config().setDocumentTitle("Red Bus Automation Report"); //title of the report
	  htmlreport.config().setReportName("Functional Report");
	  htmlreport.config().setTheme(Theme.STANDARD);
	  
	  extent = new ExtentReports();
	  extent.attachReporter(htmlreport);
	  extent.setSystemInfo("HostName","LocalHost");
	  extent.setSystemInfo("Tester name","Achin Ror");
	  extent.setSystemInfo("Browser","Chrome");
  }
}
