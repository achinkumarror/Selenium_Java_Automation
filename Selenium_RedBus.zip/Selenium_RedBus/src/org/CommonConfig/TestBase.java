package org.CommonConfig;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//TC1  - Launch the RedBus webapp

public class TestBase {
	
	public static WebDriver driver = null;
	
	  @BeforeSuite
	  public void launchbrowser() throws InterruptedException {
		  
		  ChromeOptions options = new ChromeOptions();
		  options.addArguments("--disable-notifications");//disable notification popup 
		  //options.addArguments("--incognito");

		  String driverPath = "./webdrivers\\chromedriver.exe";
			
		    System.setProperty("webdriver.chrome.driver", driverPath);

		    driver = new ChromeDriver(options); //Launch Browser - WebDriver is interface, ChromeDriver is class implementing interface
		    driver.manage().window().maximize();
		    
		    //To Open RedBus
		    driver.get("http://www.redbus.in/");  //get URL
		    
 
	  }
	  
	  
	  //TC 10 - Close the browser
	  @AfterSuite 
	public void end() throws InterruptedException
	  { 
		  
		  Thread.sleep(4000);
		  driver.quit(); //quit driver
	  }
}
