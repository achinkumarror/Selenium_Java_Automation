package org.CommonConfig;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

public class LoggerTest {
 
	static Logger Logger = LogManager.getLogger(LoggerTest.class);
	
	@Test
	public static void test()
	{
		System.out.println("Hello Log 4j");
		
		Logger.info ("This is info message");
		Logger.error ("This is error message");
		Logger.warn ("This is warn message");
		Logger.fatal ("This is fatal message");
		Logger.info ("This is info message");
		
		System.out.println("Hello Log 4j Complete");
	}
	
	
			
}
